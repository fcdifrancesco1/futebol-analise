// Proxy seguro para a API-Football (api-sports.io direto).
// A chave nunca fica exposta no frontend — fica só na variável de ambiente do projeto na Vercel.

const API_HOST = "v3.football.api-sports.io";

const ALLOWED_ENDPOINTS = new Set([
  "leagues",
  "teams",
  "teams/statistics",
  "standings",
  "fixtures",
  "fixtures/headtohead",
  "fixtures/events",
  "fixtures/lineups",
  "fixtures/statistics",
  "fixtures/players",
  "fixtures/player",
  "players/topscorers",
  "players/topassists",
  "players/topyellowcards",
  "players/topredcards",
  "players/squads",
  "players",
  "injuries",
  "odds",
  "predictions",
]);

module.exports = async (req, res) => {
  const API_KEY = process.env.FOOTBALL_API_KEY;

  if (!API_KEY) {
    res.status(500).json({
      error: "FOOTBALL_API_KEY não configurada nas variáveis de ambiente da Vercel.",
    });
    return;
  }

  const { endpoint, ...rest } = req.query || {};

  if (!endpoint) {
    res.status(400).json({ error: "Parâmetro 'endpoint' é obrigatório." });
    return;
  }

  if (!ALLOWED_ENDPOINTS.has(endpoint)) {
    res.status(400).json({ error: `Endpoint '${endpoint}' não permitido.` });
    return;
  }

  const qs = new URLSearchParams(rest).toString();
  const url = `https://${API_HOST}/${endpoint}${qs ? "?" + qs : ""}`;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12000);

  try {
    const apiResp = await fetch(url, {
      headers: {
        "x-apisports-key": API_KEY,
      },
      signal: controller.signal,
    });

    clearTimeout(timeout);
    const data = await apiResp.json();

    res.status(apiResp.status);
    res.setHeader("Cache-Control", "public, max-age=60, s-maxage=60");
    res.json(data);
  } catch (err) {
    clearTimeout(timeout);
    res.status(502).json({
      error: "Falha temporária ao consultar a API-Football.",
      details: err.name === "AbortError" ? "Timeout na resposta do servidor esportivo." : err.message,
    });
  }
};
